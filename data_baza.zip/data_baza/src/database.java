import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URL;
import java.sql.*;
import java.util.Calendar;
import java.util.Map;
import java.util.Scanner;
public class database
{
    final static String user = "root";
    final static String password = "";
    final static String url = "jdbc:mysql://localhost:3306/internship";

    public static void main(String[] args) throws SQLException{
        Scanner input = new Scanner(System.in);
        System.out.println("Select a number: ");
        System.out.println("1 -> New order");
        System.out.println("2 -> Modify order");
        System.out.println("3 -> Delete order");
        System.out.println("4 -> New customer");
        System.out.println("5 -> Modify customer");
        System.out.println("6 -> Delete customer");
        System.out.println("7 -> Exit");
        int action = input.nextInt();
        switch(action) {
            case 1: {
                System.out.println("NEW ORDER");
                newOrder();
                break;
            }
            case 2: {
                System.out.println("MODIFY ORDER");
                modifyOrder();
                break;
            }
            case 3: {
                System.out.println("DELETE ORDER");
                deleteOrder();
                break;
            }
            case 4: {
                System.out.println("NEW COSTUMER");
                newAgent();
                break;
            }
            case 5: {
                System.out.println("MODIFY COSTUMER");
                modifyAgent();
                break;
            }
            case 6: {
                System.out.println("DELETE COSTUMER");
                deleteAgent();
                break;
            }
            case 7:
                break;
        }
    }

    private static void newOrder() throws SQLException{
        try {
            Scanner input = new Scanner(System.in);
            Connection connection = DriverManager.getConnection(url, user, password);

            System.out.print("Give the costumer name that you want to input :");
            String customer_name = input.next();
            System.out.print("Give the agent code that you want to input :");
            String ag_code = input.next();
            System.out.print("Give the order number that you want to input :");
            int ord_num = input.nextInt();
            System.out.print("Give the order amount that you want to input :");
            int ord_amount = input.nextInt();
            System.out.print("Give the advance_amount that you want to input :");
            int advance_amount = input.nextInt();
            System.out.print("Give the order description that you want to input :");
            String ord_description = input.next();

            String query = "INSERT INTO ORDERS (ord_num, ord_amount, advance_amount, ord_date, cust_id, agent_id, ord_description)" +
                    "VALUES(?, ?, ?, ?, ?,?,?)";

            String query2 = "SELECT costumer.ID, orders.ID FROM CUSTOMER INNER JOIN ORDERS" +
                             "WHERE customer.cust_name = ?";

            String query3 = "SELECT agents.ID, orders.ID FROM AGENTS INNER JOIN ORDERS" +
                    "WHERE agents.agent_code = ?";

            Date date = getCurrentJavaSqlDate();
            PreparedStatement preparedStatement = connection.prepareStatement(query);

            PreparedStatement preparedStatement2 = connection.prepareStatement(query2);
            preparedStatement2.setString(1,customer_name);
            ResultSet rs = preparedStatement2.executeQuery();
            BigDecimal costumer_id = new BigDecimal(rs.getInt(1));

            PreparedStatement preparedStatement3 = connection.prepareStatement(query3);
            preparedStatement3.setString(1,ag_code);
            ResultSet rs2 = preparedStatement3.executeQuery();
            BigDecimal agent_id = new BigDecimal(rs2.getInt(1));

            preparedStatement.setInt(1, ord_num);
            preparedStatement.setInt(2, ord_amount);
            preparedStatement.setInt(3, advance_amount);
            preparedStatement.setDate(4, date);
            preparedStatement.setBigDecimal(5, costumer_id);
            preparedStatement.setBigDecimal(6, agent_id);
            preparedStatement.setString(7, ord_description);

            preparedStatement.execute();
            connection.close();
        }
        catch(SQLException e)
        {
            System.err.println("SQL Exception " + e);
        }
    }

    private static void modifyOrder() throws SQLException{
        try {
            Scanner input = new Scanner(System.in);
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.print("Give the order number that you want to modify :");
            int order_num = input.nextInt();
            System.out.print("Give the order amount:");
            int ord_amount = input.nextInt();
            System.out.print("Give the advance amount:");
            int advance_amount = input.nextInt();
            System.out.print("Give the order description that you want to input :");
            String ord_description = input.next();

            String query = "UPDATE ORDERS SET ord_amount = ?, advance_amount = ?, ord_date = ?,  ord_description = ? WHERE ord_num = ?";

            java.sql.Date date = getCurrentJavaSqlDate();
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, ord_amount);
            preparedStatement.setInt(2, advance_amount);
            preparedStatement.setDate(3, date);
            preparedStatement.setString(4, ord_description);
            preparedStatement.setInt(5,order_num);
            preparedStatement.executeUpdate();

            connection.close();
        }
        catch(SQLException e)
        {
            System.err.println("SQL Exception " + e);
        }
    }

    private static void deleteOrder() throws SQLException {
        try {
            Scanner input = new Scanner(System.in);
            Connection connection = DriverManager.getConnection(url, user, password);
            String query = "DELETE FROM ORDERS where ord_num = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            System.out.print("Give the order number that you want to delete :");
            int ord_num = input.nextInt();
            preparedStatement.setInt(1, ord_num);

            preparedStatement.execute();
            connection.close();
        }
        catch(SQLException e)
        {
            System.err.println("SQL Exception " + e);
        }
    }

    private static void newAgent() throws SQLException{
        try {
            Scanner input = new Scanner(System.in);
            Connection connection = DriverManager.getConnection(url, user, password);

            System.out.print("Give the agent code that you want to input :");
            String agent_code = input.next();
            System.out.print("Give the agent name that you want to input :");
            String agent_name = input.next();
            System.out.print("Give the working area that you want to input :");
            String working_area = input.next();
            System.out.print("Give the commission that you want to input :");
            int commission = input.nextInt();
            System.out.print("Give the agent number that you want to input :");
            int phone_number = input.nextInt();
            System.out.print("Give the country that you want to input :");
            String country = input.next();

            String query = "INSERT INTO AGENTS (agent_code, agent_name, working_area, commission, phone_no, country)" +
                    "VALUES(?, ?, ?, ?, ?, ?)";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, agent_code);
            preparedStatement.setString(2, agent_name);
            preparedStatement.setString(3, working_area);
            preparedStatement.setInt(4, commission);
            preparedStatement.setInt(5, phone_number);
            preparedStatement.setString(6, country);
            preparedStatement.execute();
            connection.close();
        }
        catch(SQLException e)
        {
            System.err.println("SQL Exception " + e);
        }
    }

    private static void modifyAgent() throws SQLException{
        try {
            Scanner input = new Scanner(System.in);
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.print("Give the agent code that you want to modify :");
            String agent_code = input.next();
            System.out.print("Give the agent name:");
            String agent_name = input.next();
            System.out.print("Give the working area:");
            String working_area = input.next();
            System.out.print("Give the commission:");
            int commission = input.nextInt();
            System.out.print("Give the agent number:");
            int phone_number = input.nextInt();
            System.out.print("Give the country:");
            String country = input.next();

            String query = "UPDATE AGENTS SET agent_name = ?, working_area = ?, commission = ?,  phone_no = ?, country = ? WHERE agent_code = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, agent_name);
            preparedStatement.setString(2, working_area);
            preparedStatement.setInt(3, commission);
            preparedStatement.setInt(4, phone_number);
            preparedStatement.setString(5, country);
            preparedStatement.setString(6, agent_code);
            preparedStatement.executeUpdate();

            connection.close();
        }
        catch(SQLException e)
        {
            System.err.println("SQL Exception " + e);
        }
    }

    private static void deleteAgent() throws SQLException {
        try {
            Scanner input = new Scanner(System.in);
            Connection connection = DriverManager.getConnection(url, user, password);
            String query = "DELETE FROM AGENTS where agent_code = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            System.out.print("Give the agent code that you want to delete :");
            int agent_code = input.nextInt();
            preparedStatement.setInt(1, agent_code);

            preparedStatement.execute();
            connection.close();
        }
        catch(SQLException e)
        {
            System.err.println("SQL Exception " + e);
        }
    }

    private static Date getCurrentJavaSqlDate() {
        java.util.Date today = new java.util.Date();
        return new java.sql.Date(today.getTime());
    }
}