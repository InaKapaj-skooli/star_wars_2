package de.lhind.internship.model;

//POJO - PLAIN OLD JAVA OBJECT
public class Order<date> {

    private int ord_num;
    private int ord_amount;
    private int advance_amount;
    private int cust_id;
    private int agent_id;
    private date date;
    private String ord_description;

    public int getOrdNum() {
        return ord_num;
    }

    public void setOrdNum(int ord_num) {
        this.ord_num = ord_num;
    }

    public int getOrdAmount() {
        return ord_amount;
    }

    public void setOrdAmount(int ord_amount) {
        this.ord_amount = ord_amount;
    }

    public int getAdvanceAmount() {
        return advance_amount;
    }

    public void setAdvanceAmount(int advance_amount) {
        this.advance_amount = advance_amount;
    }

    public int getCustId() {
        return cust_id;
    }

    public void setCustId(int cust_id) {
        this.cust_id = cust_id;
    }

    public int getAgentId() {
        return agent_id;
    }

    public void setAgentId(int agent_id) {
        this.agent_id = agent_id;
    }

    public date getDate() {
        return date;
    }

    public void setDate(date date) {
        this.date = date;
    }

    public String getOrdDescription() {
        return ord_description;
    }

    public void setOrdDescription(String ord_description) {
        this.ord_description = ord_description;
    }
}