package de.lhind.internship.service;

import de.lhind.internship.model.Order;
import java.sql.SQLException;
import java.util.List;

public interface OrderService {

    List<Order> getAllOrders() throws SQLException;
}