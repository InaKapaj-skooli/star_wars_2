package de.lhind.internship.service;

import de.lhind.internship.model.Order;
import de.lhind.internship.repository.OrderRepository;
import de.lhind.internship.repository.OrderRepositoryImpl;

import java.sql.SQLException;
import java.util.List;

public abstract class OrderServiceImpl implements OrderService {

    OrderRepository orderRepository = new OrderRepositoryImpl();


    public List<Order> newOrder() throws SQLException {
        return OrderRepository.newOrder();
    }
    public List<Order> modifyOrder() throws SQLException {
        return OrderRepository.newOrder();
    }
    public List<Order> deleteOrder() throws SQLException {
        return OrderRepository.newOrder();
    }
}
