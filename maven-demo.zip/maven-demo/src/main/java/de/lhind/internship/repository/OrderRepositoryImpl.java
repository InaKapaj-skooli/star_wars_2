package de.lhind.internship.repository;

import de.lhind.internship.model.Order;
import de.lhind.internship.utils.MySQLConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//DAO
public class OrderRepositoryImpl implements OrderRepository {

    public List<Order>  newOrder() throws SQLException {
        Connection connection = MySQLConnection.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM offices;");
        ResultSet resultSet = preparedStatement.executeQuery();
        List<Order> offices = new ArrayList<>();
        while (resultSet.next()) {
            offices.add(buildOrder(resultSet));
        }
        preparedStatement.execute();
        connection.close();
        return null;
    }

    public List<Order> modifyOrder() throws SQLException {
        Connection connection = MySQLConnection.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement("UPDATE ORDERS SET ord_amount = ?, advance_amount = ?, ord_date = ?,  ord_description = ? WHERE ord_num = ?");
        ResultSet resultSet = preparedStatement.executeQuery();
        List<Order> offices = new ArrayList<>();
        while (resultSet.next()) {
            offices.add(modifyOrder(resultSet));
        }
        preparedStatement.executeUpdate();
        connection.close();
        return null;
    }

    public List<Order>  deleteOrder() throws SQLException {
        Connection connection = MySQLConnection.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM ORDERS where ord_num = ?");
        ResultSet resultSet = preparedStatement.executeQuery();
        List<Order> orders = new ArrayList<>();
        while (resultSet.next()) {
            orders.add(deleteOrder(resultSet));
        }
        preparedStatement.execute();
        connection.close();
        return null;
    }

    static Order buildOrder(ResultSet resultSet) throws SQLException {
        Order order = new Order();

        Scanner input = new Scanner(System.in);

        System.out.print("Give the costumer name that you want to input :");
        String customer_name = input.next();
        System.out.print("Give the agent code that you want to input :");
        String ag_code = input.next();
        System.out.print("Give the order number that you want to input :");
        int ord_num = input.nextInt();
        System.out.print("Give the order amount that you want to input :");
        int ord_amount = input.nextInt();
        System.out.print("Give the advance_amount that you want to input :");
        int advance_amount = input.nextInt();
        System.out.print("Give the order description that you want to input :");
        String ord_description = input.next();
        Date date = getCurrentJavaSqlDate();

        order.setOrdNum(ord_num);
        order.setOrdAmount(ord_amount);
        order.setAdvanceAmount(advance_amount);
        order.setAgentId(5);
        order.setDate(date);
        order.setCustId(3);
        order.setOrdDescription(ord_description);
        return order;
    }

    static Order modifyOrder(ResultSet resultSet) throws SQLException {
        Order order = new Order();
        Scanner input = new Scanner(System.in);

        System.out.print("Give the order number that you want to modify :");
        int order_num = input.nextInt();
        System.out.print("Give the order amount:");
        int ord_amount = input.nextInt();
        System.out.print("Give the advance amount:");
        int advance_amount = input.nextInt();
        System.out.print("Give the order description that you want to input :");
        String ord_description = input.next();
        Date date = getCurrentJavaSqlDate();

        order.setOrdAmount(ord_amount);
        order.setAdvanceAmount(advance_amount);
        order.setDate(date);
        order.setOrdDescription(ord_description);
        order.setOrdNum(order_num);

        return order;
    }

    static Order deleteOrder(ResultSet resultSet) throws SQLException{
        Order order = new Order();
        Scanner input = new Scanner(System.in);

        System.out.print("Give the order number that you want to delete :");
        int ord_num = input.nextInt();
        order.setOrdNum(ord_num);

        return order;
    }

    private static Date getCurrentJavaSqlDate() {
        java.util.Date today = new java.util.Date();
        return new java.sql.Date(today.getTime());
    }
}
