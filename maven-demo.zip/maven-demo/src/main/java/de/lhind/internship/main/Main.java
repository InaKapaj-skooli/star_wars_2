package de.lhind.internship.main;

import de.lhind.internship.model.Order;
import de.lhind.internship.repository.OrderRepository;
import de.lhind.internship.service.OrderService;
import de.lhind.internship.service.OrderServiceImpl;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public abstract class Main implements OrderRepository {
    public static void main(String[] args) {
        try {
            Scanner input = new Scanner(System.in);
            System.out.println("Select a number: ");
            System.out.println("1 -> New order");
            System.out.println("2 -> Modify order");
            System.out.println("3 -> Delete order");
            System.out.println("7 -> Exit");
            int action = input.nextInt();
            switch(action) {
                case 1: {
                    System.out.println("NEW ORDER");
                    OrderRepository.newOrder();
                    break;
                }
                case 2: {
                    System.out.println("MODIFY ORDER");
                    OrderRepository.modifyOrder();
                    break;
                }
                case 3: {
                    System.out.println("DELETE ORDER");
                    OrderRepository.deleteOrder();
                    break;
                }
                case 4:
                    break;
            }
        }
        catch (SQLException e) {
            System.err.println(e);
        }
    }
}
