package de.lhind.internship.repository;

import de.lhind.internship.model.Order;

import java.sql.SQLException;
import java.util.List;

public interface OrderRepository {

    static List<Order> newOrder() throws SQLException {
        return null;
    }

    static List<Order> modifyOrder() throws SQLException {
        return null;
    }

    static List<Order> deleteOrder() throws SQLException {
        return null;
    }
}
